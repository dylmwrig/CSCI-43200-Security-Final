from bottle import default_app, route, template, get, post, request
import sqlite3

db = sqlite3.connect("./mysite/testdb.db")
c = db.cursor()

###########################################

@route('/testPage')
def testPage():
    return template("testPage.html", db=db, c=c)

@route('/')
def reroute():
    return template("getInput.html")

# HANDLES DISPLAYING THE /getInput PAGE
@get('/getInput')
def getInput():
    return template("getInput.html")


# HANDLES PROCESSING THE FORM ON THE /getInput PAGE AFTER THE USER CLICKS SUBMIT
@post('/getInput')
def doInput():
    txtField = request.forms.get('txtField')
    passField = request.forms.get('passField')
    return template("doInput.html", txtField=txtField, passField=passField, db=db, c=c)


@get('/search')
def search():
    return template("search.html")


@post('/search')
def doSearch():
    txtField = request.forms.get('txtField')
    return template("doSearch.html", txtField=txtField, db=db, c=c)


@get('/update')
def update():
    return template("update.html")


@post('/update')
def doUpdate():
    txtField = request.forms.get('txtField')
    passField = request.forms.get('passField')
    newPass = request.forms.get('newPass')
    return template("doUpdate.html", txtField=txtField, passField=passField, newPass=newPass, db=db, c=c)


@get('/removeProduct')
def removeProduct():
    return template("removeProduct")


@post('/removeProduct')
def doRemoveProduct():
    txtField = request.forms.get('txtField')
    return template("doRemoveProduct.html", txtField=txtField, db=db, c=c)


# HANDLES RESETTING THE DATABASE WITH DEFAULT USERS AND PASSWORDS
@route('/resetDB')
def resetDB():

    c.execute('DROP TABLE IF EXISTS users')
    sqlScript = '''
    CREATE TABLE users (
        id INTEGER PRIMARY KEY,
        name VARCHAR (255),
        password VARCHAR (255)
    ) '''

    c.execute(sqlScript)
    db.commit()

    c.execute("INSERT INTO users VALUES (null, ?, ?)", ("admin", "Pa$$w0rd"))
    c.execute("INSERT INTO users VALUES (null, ?, ?)", ("just_a_guy", "s3cr3t"))
    c.execute("INSERT INTO users VALUES (null, ?, ?)", ("imAUser", "thisMyPassword"))
    db.commit()

    c.execute('DROP TABLE IF EXISTS products')
    sqlScript = '''
    CREATE TABLE products (
        id INTEGER PRIMARY KEY,
        name VARCHAR (255),
        price FLOAT (100),
        amount INT (100),
        released INT (1)
    ) '''

    c.execute(sqlScript)
    db.commit()

    c.execute("INSERT INTO products VALUES (null, ?, ?, ?, ?)", ("10mm nails", 10.99, 250, 1))
    c.execute("INSERT INTO products VALUES (null, ?, ?, ?, ?)", ("20mm nails", 11.99, 180, 1))
    c.execute("INSERT INTO products VALUES (null, ?, ?, ?, ?)", ("flathead screwdriver", 4.99, 90, 1))
    c.execute("INSERT INTO products VALUES (null, ?, ?, ?, ?)", ("tape measure", 4.99, 100, 1))
    c.execute("INSERT INTO products VALUES (null, ?, ?, ?, ?)", ("top secret product", 99.99, 200, 0))
    db.commit()

    return template("resetDB.html", db=db, c=c)


# HANDLES VIEWING THE DATABASE
@route('/viewDB')
def viewDB():
    return template("viewDB.html", db=db, c=c)


application = default_app() #not sure what this does but everything breaks without it :)

